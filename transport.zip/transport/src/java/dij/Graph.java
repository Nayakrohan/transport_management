/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dij;

/**
 *
 * @author admin
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Graph {
    int nodes;
 static int edges;
 static int grph[][];
 

public static void dijk(Graph g, int src)
 {
  int distance[] = new int[g.nodes];
  int previous[] = new int[g.nodes];
  String path[] = new String[g.nodes];
  for(int i = 0; i < g.nodes; i++)
  {
   distance[i] = 9999;
   previous[i] = -1;
   path[i] = "";
  }
  distance[src] = 0;
  for(int i = 0; i < g.nodes; i++)
  {
   for(int j = 0; j < g.nodes; j++)
   {
    if(distance[i] + g.grph[i][j] < distance[j])
    {
     distance[j] = distance[i] + g.grph[i][j];
     previous[j] = i;
    }
   }
  }
  for(int i = 0; i < g.nodes; i++)
  {
   int current = i;
   do
   {
    path[i] = "-" + (current + 1) + path[i];
    current = previous[current];
   }
   while(current != -1);
   path[i] = path[i].substring(1, path[i].length());
  }
  System.out.println();
  for(int i = 0; i < g.nodes; i++)
  {
   if(i != src)
   {
    System.out.println("The shortest path & its distance for node " + (i + 1) + " is:");
    System.out.print("Path: " + path[i]);
    System.out.println(" Distance: " + distance[i]);
   }
  }
 }
public static void accept(int nodes,int edges) throws IOException
{
  
  grph = new int[nodes][nodes];
  for(int i = 0; i < nodes; i++)
   for(int j = 0; j < nodes; j++)
    grph[i][j] = 9999;
 
 }
public static void accept1(int source,int destination,int distance) throws IOException
{
     for(int i = 0; i < edges; i++)
  {
   
   grph[source - 1][destination - 1] = distance;
   grph[destination - 1][source - 1] = distance;
  } 
}



    
}
